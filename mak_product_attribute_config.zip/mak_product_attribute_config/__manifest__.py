# -*- coding: utf-8 -*-


{
    'name': "Product Attributes Extended",
    'version': '13.0.1.0.0',
    'summary': """Product Attributes Extended""",
    'description': """This module will store all Product Attributes.""",
    'author': "MakERP",
    'company': " MakERP",
    'category': 'Inventory',
    'depends': ['product', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/product_attrib_config_view.xml'
    ],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
}
