
from odoo import api, fields, models, tools, SUPERUSER_ID

from collections import OrderedDict



class ProductAttributes(models.Model):
    _name = 'product.attribute.configuration'

    product_id = fields.Many2one('product.product', string='Product')
    attributes_config_ids = fields.One2many('attribute.configuration', 'config_id', string='Attributes')

class AttributeConfig(models.Model):
    _name = 'attribute.configuration'

    config_id = fields.Many2one('product.attribute.configuration',string='Config ID')
    attribute_id = fields.Many2one('product.attribute', string='Attribute')
    value_ids = fields.Many2many('product.attribute.value', string="Values", domain="[('attribute_id', '=', attribute_id)]",
                     relation='product_attribute_value_product_product_new_attribute_line_rel', ondelete='restrict')